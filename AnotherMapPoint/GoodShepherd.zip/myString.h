#pragma once 
#include <iostream>
namespace mystring{
class String{
  friend String operator*(int a,const String &data);
public:
String(const String &dummy);
String();
~String();
String( const char *data);
String(String &&a);
void print(const char *data)const;
bool operator==(const String &a)const;
bool operator==(const char *a)const;
String operator+(const char *a)const;
String operator+(String &a)const;
String operator+(char a)const;
operator char *()const;
String operator=(const String &dummy);
void operator=(const char *dummy);
private:
  int size;
  char  *string;
};
String operator*(int a,const String &data);
}