#include "myString.h"
#include<cstring>
#include <utility>
mystring::String mystring::String::operator=(const String &data){
    return String(data);
}
void mystring::String::operator=(const char *data){
  delete [] string;
  string=nullptr;
  string= new char[size+strlen(data)+1];
  size=size+strlen(data)+1;
  strcpy(string, data);
}
mystring::String::String(const String &data){
    size=data.size+1;
    string=new char[size];
    strcpy(string, data.string);
}
mystring::String::String(){
  string=nullptr;
  size=0;
}
mystring::String::~String(){
  delete[]string;
}
mystring::String::String(String &&a){
  string=std::exchange(a.string,nullptr);
  size=std::exchange(a.size,0);
}
mystring::String::String(const char  *data){
  size=strlen(data)+1; 
  string= new char[size];
  strcpy(string,data);
}
void mystring::String::print(const char *data)const{
std::cout<<data<<string<<"\n";
}
bool mystring::String::operator==(const String &a)const{
  if(strcmp(string,a.string))return false;
  else return true;
}
bool mystring::String::operator==(const char  *a)const{
  if(strcmp(string,a))return false;
  else return true;
}
mystring::String::operator char *()const{
  return string;
}
  mystring::String mystring::String::operator+(const char*a)const{
    String add;
add.string= new char[size+strlen(a)+1];
add.size=size+strlen(a)+1;
strcpy(add.string,string);
strcat(add.string,a);
return add;
}
  mystring::String mystring::String::operator+(char a)const{
  String add;
  add.size=size+1;
  add.string= new char[size+1];
strcpy(add.string,string);
add.string[size]=a;
return add;
}
  mystring::String mystring::String::operator+(String &a)const{
    String add;
    add.size=size+a.size;
add.string= new char[size+a.size];
strcpy(add.string,string);
strcat(add.string,a.string);
return add;
}
mystring::String mystring::operator*(int a,const String &data){
  String add;
  add.string=new char[a*data.size-a+1];
  add.size=a*data.size-a+1;
  strcpy(add.string,data.string);
  for(int i=1;i<a;i++)strcat(add.string,data.string);
  return add;
}